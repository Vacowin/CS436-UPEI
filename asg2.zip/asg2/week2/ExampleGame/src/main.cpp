//------------------------------------------------------------------------
// main
//
// Created:	2012/12/06
// Author:	Carel Boers
//	
// Main entry point of the game. Create a game, and run it.
//------------------------------------------------------------------------

#include "ExampleGame.h"

int main(int argc, char* argv[])
{
	week2::ExampleGame exampleGame;
	return exampleGame.Run();
}


