Hold left mouse and move mouse to rotate the camera.
Stop criteria of quad tree is 3 nodes in one quad.
If one node belongs to more than one quad, that node will be stored in the parent quadtree.