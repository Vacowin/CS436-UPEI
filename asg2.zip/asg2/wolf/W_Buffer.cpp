//-----------------------------------------------------------------------------
// File:			W_Buffer.cpp
// Original Author:	Gordon Wood
//
// See header for notes
//-----------------------------------------------------------------------------
#include "W_Buffer.h"

namespace wolf
{
}
